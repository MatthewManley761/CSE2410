package edu.fit.cse2410.group_project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RequestMapping("/api")
@RestController
public class FitnessUserController {

    @Autowired
    FitnessUserRepository fitnessRepo;

    //gets everything for all users
    @GetMapping("/fitnessUsers")
    public ResponseEntity<List<FitnessUser>> getAll() {
        try {
            List<FitnessUser> usersList = new ArrayList<FitnessUser>();

            fitnessRepo.findAll().forEach(usersList::add);

            if (usersList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>(usersList, HttpStatus.OK);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //gets everything for a user
    @GetMapping("/fitnessUsers/{id}")
    public ResponseEntity<FitnessUser> getUserByID(@PathVariable("id") Integer id) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            return new ResponseEntity<>(userData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //adds a user
    @PostMapping("/fitnessUsers")
    public ResponseEntity<FitnessUser> addUser(@RequestBody FitnessUser fitnessUser) {
        try {
            FitnessUser _fitnessUser = fitnessRepo
                    .save(new FitnessUser(fitnessUser.getUsername(), fitnessUser.getPassword()));
            return new ResponseEntity<>(_fitnessUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //adds a user
    @PostMapping("/fitnessUsers/addUsername/{username}")
    public ResponseEntity<FitnessUser> addUser(@PathVariable("username") String username) {
        try {
            FitnessUser _fitnessUser = fitnessRepo
                    .save(new FitnessUser(username, "12345"));
            return new ResponseEntity<>(_fitnessUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //update an entire user with all fields. Pass in object.
    @PutMapping("/fitnessUsers/{id}")
    public ResponseEntity<FitnessUser> updateFitnessUser(@PathVariable("id") Integer id, @RequestBody FitnessUser fitnessUser) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            return new ResponseEntity<>(fitnessRepo.save(fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the username
    @PutMapping("/fitnessUsers/updateUsername/{id}/{username}")
    public ResponseEntity<FitnessUser> updateUsername(@PathVariable("id") Integer id, @PathVariable("username") String username) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setUsername(username);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the password
    @PutMapping("/fitnessUsers/updatePassword/{id}/{password}")
    public ResponseEntity<FitnessUser> updatePassword(@PathVariable("id") Integer id, @PathVariable("password") String password) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setPassword(password);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the email
    @PutMapping("/fitnessUsers/updateEmail/{id}/{email}")
    public ResponseEntity<FitnessUser> updateEmail(@PathVariable("id") Integer id, @PathVariable("email") String email) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setEmail(email);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the age
    @PutMapping("/fitnessUsers/updateAge/{id}/{age}")
    public ResponseEntity<FitnessUser> updateAge(@PathVariable("id") Integer id, @PathVariable("age") Integer age) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setAge(age);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the height(in inches)
    @PutMapping("/fitnessUsers/updateHeight/{id}/{height}")
    public ResponseEntity<FitnessUser> updateHeight(@PathVariable("id") Integer id, @PathVariable("height") float height) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setHeight_inches(height);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
    //update the current weight
    @PutMapping("/fitnessUsers/updateCurrentWeight/{id}/{CurrentWeight}")
    public ResponseEntity<FitnessUser> updateCurrentWeight(@PathVariable("id") Integer id, @PathVariable("CurrentWeight") float current_weight_pounds) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setCurrent_weight_pounds(current_weight_pounds);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the goal weight
    @PutMapping("/fitnessUsers/updateGoalWeight/{id}/{GoalWeight}")
    public ResponseEntity<FitnessUser> updateGoalWeight(@PathVariable("id") Integer id, @PathVariable("GoalWeight") float goal_weight_pounds) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setGoal_weight_pounds(goal_weight_pounds);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    //update the goal steps
    @PutMapping("/fitnessUsers/updateGoalSteps/{id}/{GoalSteps}")
    public ResponseEntity<FitnessUser> updateGoalSteps(@PathVariable("id") Integer id, @PathVariable("GoalSteps") Integer goal_steps) {
        Optional<FitnessUser> userData = fitnessRepo.findById(id);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setGoal_steps(goal_steps);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }


    //delete a user
    @DeleteMapping("/fitnessUsers/{id}")
    public ResponseEntity<HttpStatus> deleteFitnessUser(@PathVariable("id") Integer id) {
        try {
            fitnessRepo.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
