package edu.fit.cse2410.group_project;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class FitnessUser {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer day;

    @Column
    private Integer step_number;

    public FitnessUser() {
    }

    public FitnessUser(Integer step_number) {
        this.step_number = step_number;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getStep_number() {
        return step_number;
    }

    public void setStep_number(Integer step_number) {
        this.step_number = step_number;
    }
}
