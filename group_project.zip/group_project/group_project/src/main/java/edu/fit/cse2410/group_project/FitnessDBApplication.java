package edu.fit.cse2410.group_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnessDBApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessDBApplication.class, args);
	}

}
