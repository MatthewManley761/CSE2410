package edu.fit.cse2410.group_project;

import org.springframework.data.jpa.repository.JpaRepository;

import javax.persistence.Column;
import java.util.List;

public interface FitnessUserRepository extends JpaRepository<FitnessUser, Integer> {
}