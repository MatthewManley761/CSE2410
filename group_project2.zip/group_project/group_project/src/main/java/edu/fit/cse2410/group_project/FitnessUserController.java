package edu.fit.cse2410.group_project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RequestMapping("/api")
@RestController
public class FitnessUserController {

    @Autowired
    FitnessUserRepository fitnessRepo;

    //gets all steps
    @GetMapping("/fitnessUsers")
    public ResponseEntity<List<FitnessUser>> getAll() {
        try {
            List<FitnessUser> usersList = new ArrayList<FitnessUser>();

            fitnessRepo.findAll().forEach(usersList::add);

            if (usersList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>(usersList, HttpStatus.OK);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //get steps for a given day
    @GetMapping("/fitnessUsers/{day}")
    public ResponseEntity<FitnessUser> getUserByID(@PathVariable("day") Integer day) {
        Optional<FitnessUser> userData = fitnessRepo.findById(day);

        if (userData.isPresent()) {
            return new ResponseEntity<>(userData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //adds daily steps row
    @PostMapping("/fitnessUsers/addSteps/{steps}")
    public ResponseEntity<FitnessUser> addUser(@PathVariable("steps") Integer steps) {
        try {
            FitnessUser _fitnessUser = fitnessRepo
                    .save(new FitnessUser(steps));
            return new ResponseEntity<>(_fitnessUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    //change steps for a specific day
    @PutMapping("/fitnessUsers/updateSteps/{day}/{steps}")
    public ResponseEntity<FitnessUser> updateUsername(@PathVariable("day") Integer day, @PathVariable("steps") Integer steps) {
        Optional<FitnessUser> userData = fitnessRepo.findById(day);

        if (userData.isPresent()) {
            FitnessUser _fitnessUser = userData.get();
            _fitnessUser.setStep_number(steps);
            return new ResponseEntity<>(fitnessRepo.save(_fitnessUser), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
}
